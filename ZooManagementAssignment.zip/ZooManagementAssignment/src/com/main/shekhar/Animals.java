package com.main.shekhar;
import com.main.about.*;
import java.util.Arrays;

import com.main.Main;
import com.main.about.Welcome;

public class Animals implements Welcome {
String[] animal= {"lion","tiger","wolf","lamb"};
public String welcome(String zooname) {
	return "welcome to "+zooname;
}
public String toString() {
	return "Animals present here are" +"["+ Arrays.toString(animal)+"]";
}
}
