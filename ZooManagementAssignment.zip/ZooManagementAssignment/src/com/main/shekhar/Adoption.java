package com.main.shekhar;
import com.main.about.Welcome;
import com.main.travel.Ferrari;

public class Adoption extends Ferrari implements Welcome{
	public String welcome(String zooname) {
		return "welcome to "+zooname+" love animals and adopt the animals";
	}

	public static void main(String[] args) {
		Ferrari j=new Ferrari ();
		System.out.println(j.toString());
	
}
	}