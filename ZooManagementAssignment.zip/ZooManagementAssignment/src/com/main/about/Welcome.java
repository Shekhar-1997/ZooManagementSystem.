package com.main.about;

public interface Welcome {
 String welcome(String zooname);
}
