package com.main.travel;

public class Ferrari{
	@Override
	public String toString() {
		return "to book 4x4 Jeep contact number=" + contact_no ;
	}
	static long contact_no=1234567890;
}
